
import java.util.Arrays;
import java.util.List;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
import java.util.stream.Collectors;
import java.util.stream.Stream;

// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        List<String> list = Arrays.asList("a", "b", "c");
        list.stream().forEach(System.out::println);

        String arr[]={"x","y","z"};
        Arrays.stream(arr).forEach(System.out::println);

        List<String> words = Arrays.asList("apple", "banana", "cherry", "date");

        List<String> filteredWords = words.stream()
                .filter(word -> word.startsWith("a"))
                .map(String::toUpperCase)
                        .collect(Collectors.toList());

        System.out.println(filteredWords);

        words.stream().filter(word -> word.startsWith("b"))
                .forEach(System.out::println);
    }
}